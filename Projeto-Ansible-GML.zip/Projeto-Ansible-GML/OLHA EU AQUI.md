### Passos para execução

1. Abra o terminal.
2. Navegue até o diretório do projeto:

    ```sh
    Projeto-Ansible-GML
    ```

3. Execute o comando Ansible Playbook:

    ```sh
    ansible-playbook install-vscode.yaml -i inventory.ini --ask-vault-pass
    ```

4. Insira a senha do Vault `12345678` quando solicitado.("ou outra caso tenha trocado")
### Observações

- Certifique-se de que o arquivo [inventory.ini](http://_vscodecontentref_/4) contém as informações corretas dos hosts.
- O comando `--ask-vault-pass` solicitará a senha do Vault para descriptografar o arquivo [become_pass.yml](http://_vscodecontentref_/5).



